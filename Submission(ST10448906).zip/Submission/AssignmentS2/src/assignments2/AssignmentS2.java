package assignments2;

import java.util.ArrayList;
import java.util.Scanner;


public class AssignmentS2 {
    
    public static void main(String[] args) {
        
       
        Student obj = new Student();
        
        obj.menuScreen();
        
        
    }

    /**
     *
     * @return
     */
    public static ArrayList<Student> saveStudent(){//(Farrel,2023)
        
        ArrayList<Student> students = new ArrayList<>();//(Farrel,2023)
            
            Scanner input = new Scanner(System.in);
           
        while(true){//(Farrel,2023)
            System.out.println("Enter student ID: ");
            int id = input.nextInt();
            
            System.out.println("Enter student name: ");
            String name = input.next();
            
            int age;
            System.out.println("Enter student age");
            while(true){
                try{
                    age = input.nextInt();
                    
                    if(age >= 16 ){
                        break;
                    }
                    else{
                        System.out.println("You have entered incorrect student age!!! \nPlease re-enter the student age!!!");
                    }
                }catch(NumberFormatException | ArithmeticException e){
                    System.out.println("You have entered incorrect student age!!! \nPlease re-enter the student age!!!");
                }
            }
            
            System.out.println("Enter student email:");
            String email = input.next();
            
            System.out.println("Enter student course:");
            String course = input.next();
            
            System.out.println("Details has been succesfully captured!!!");

            
            Student student = new Student(id,name,age,email,course);//(Farrel,2023)
            students.add(new Student(student));//(Farrel,2023)
            
            System.out.println("Would you like to add another student? yes(1)/no(2))");
            int answer = input.nextInt();
            if(answer == 2){
               break;
            }
        }
        return students;
    }
           
}
//Reference list:
//Farell,  J. 2023. Java programming. 10th Edition. Boston: Cengage.
