package assignments2;

import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Ricardo
 */
public class AssignmentS2Test {
    
    private ArrayList<Student> students;
    private Student student;
    
    
     public void setUp(){
        students = new ArrayList<>();
        student = new Student(1011,"Blessing",17,"blessing@gmail.com","BCA1");
        students.add(student);
    }
    @Test
    public void testSaveStudent(){
        Student newStudent = new Student(1012,"John",18,"John@gmail.com","BCA1");
        students.add(newStudent);
        assertEquals(2,students.size());
        assertEquals("John",students.get(1).getName());
    }
    
    @Test
    public void testSearchStudent(){
        Student foundStudent = searchStudent(1);
        assertNotNull(foundStudent);
        assertEquals("John",foundStudent.getName());
    } 
    public Student searchStudent(int id){
        for(Student student: students){
            if(student.getId() == id){
                return student;
            }
        }
        return null;
    }
    
    @Test
    public void testSearchStudent_StudentNotFound(){
        Student foundStudent = searchStudent(99);
        assertNull(foundStudent);
    }
    
    @Test
    public void testDeleteStudent(){
        deleteStudent(1);
        assertEquals(0,students.size());
    }
    
    @Test
    public void testDeleteStudent_StudentNotFound(){
        deleteStudent(99);
        assertEquals(1,students.size());
    }
    
    @Test
    public void testStudentAge_StudentAgeValid(){
        boolean isValid = validateAge(18);
        assertTrue(isValid);
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalid(){
        boolean isValid = validateAge(15);
        assertFalse(isValid);
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter(){
        validateAge("ab");
    }
    private void deleteStudent(int id){
        Student studentToDelete = null;
        for(Student student: students){
            if(student.getId() == id){
            studentToDelete = student;
            break;
            }
        }
        if(studentToDelete != null){
            students.remove(studentToDelete);
        }
    }
    
    private boolean validateAge(int age){
        return age >= 16;
    }
    
    private boolean validateAge(String age){
        try{
            return validateAge(Integer.parseInt(age));
        }catch(NumberFormatException e){
            throw e;
        }
    }
    public AssignmentS2Test() {
        
    }

    @Test
    public void testSomeMethod() {
        
        Student newStudent = new Student(1012,"John",18,"John@gmail.com","BCA1");
        students.add(newStudent);
        assertEquals(2,students.size());
        assertEquals("John",students.get(1).getName());
    }
    
}
