package assignments2;

import java.util.ArrayList;
import java.util.*;


public class AssignmentS2 {
    
    public static void main(String[] args) {
        
       
        Student obj = new Student();
        
        obj.menuScreen();//Comment
        
        
    }
    public static ArrayList<Student> capture(){
        
        ArrayList<Student> students = new ArrayList<>();
            
            Scanner input = new Scanner(System.in);
            Student obj = new Student();
            System.out.println("Enter student ID: ");
            int id = input.nextInt(); 
            int age;
            System.out.println("Enter student name: ");
            String name = input.next();
            
            System.out.println("Enter student age");
            while(true){
                try{
                    age = Integer.parseInt(input.next());
                    if(age >= 16 ){
                        break;
                    }
                    else{
                        System.out.println("You have entered incorrect student age!!! \nPlease re-enter the student age!!!");
                    }
                }catch(NumberFormatException | ArithmeticException e){
                    System.out.println("You have entered incorrect student age!!! \nPlease re-enter the student age!!!");
                }
            }
            
            System.out.println("Enter student email:");
            String email = input.next();
            
            System.out.println("Enter student course:");
            String course = input.next();
            System.out.println("Details has been succesfully captured!!!");
            
            System.out.println("Enter (1) to launch menu or any other key to exit.");
            int choice = input.nextInt();
            if(choice == 1){
                obj.menu(students);
            }
            else{
                System.out.println("You are exsiting the program.");
            }
       
            
            Student student = new Student(id,name,age,email,course);
            students.add(student);
            
            return students;
    }
}
