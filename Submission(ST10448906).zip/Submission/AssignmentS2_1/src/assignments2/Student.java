package assignments2;

import java.util.*;
import javax.swing.JOptionPane;

public class Student {
    
    Scanner input = new Scanner(System.in);
    
    private String name,email,course;
    private int id,age;
    
    
        public Student(){
            name = email = course = null;
            id =  age =  0;
        }
        public Student(int id,String name,int age, String email,String course){
            this.id = id;
            this.name = name;
            this.age = age;
            this.email = email;
            this.course = course;
        }
            public String getName(){
                return name;
            }
            public int getId(){
                return id;
            }
            public int getAge(){
                return age;
            }
            public String email(){
                return email;
            }
            public String getCourse(){
                return course;
            }
            public void setName(String n){
                name = n;
            }
            public void setId(int i){
                id = i;
            }
            public void setAge(int a){
                age = a;
            }
            public void setEmail(String e){
                email = e;
            }
            public void setCourse(String c){
                course = c;
            }
            public void menuScreen(){
                ArrayList<Student> students = null;
                int choice;
                //System.out.println("STUDENT MANAGEMENT APPLICATION \n************************** \nEnter (1) to launch menu or any other key to exit.");
                choice = Integer.parseInt(JOptionPane.showInputDialog("Enter (1) to launch menu or any other key to exit."));
                
                if(choice == 1){
                    menu(students);
                }
                else{
                    System.out.println("Exsiting program.");
                }
            }
            public void menu(ArrayList<Student> students){
                int choice;
                //System.out.println("Please select one of the following menu items: \n(1) Capture a new student. \n(2) Search for a student \n(3) Delete a student \n(4) Print student report \n(5) Exit Application");
                
                do{
                    
                    choice = Integer.parseInt(JOptionPane.showInputDialog("Please select one of the following menu items: \\n(1) Capture a new student. \\n(2) Search for a student \\n(3) Delete a student \\n(4) Print student report \\n(5) Exit Application"));
                    
                    switch(choice){
                       
                        case 1:
                                AssignmentS2.capture();
                            break;
                        case 2:
                                search(students);
                            break;
                        case 3:
                                System.out.println("Enter student number: ");
                                int option = input.nextInt();
                                deleteStudent(students,option);
                            break;
                        case 4:
                               display(students);
                            break;
                        case 5: 
                                System.out.println("You are exsiting the application.");
                            break;
                        default: System.out.println("Invalid input,please try again.");
                    }
                    
                }while(choice != 5);
            }
      
            public String search(ArrayList<Student> students){
                return "";
            }
            public void deleteStudent(ArrayList<Student> students,int option){
                Student studentToDelete = null;
                
                for(Student student : students){
                    if(student.getId() == option){
                        studentToDelete = student;
                        break;
                    }
                }
                
                System.out.println("Are you sure to want to delete it? Yes (y) to delete");
                String choice = input.next();
                
                if(studentToDelete != null && choice.equals(choice)){
                    students.remove(studentToDelete);
                    System.out.println("Student with ID: " + option + " was deleted!!");
                }
                else{
                    System.out.println("Student " + option + " was not found!!");
                }
            }
            public void display(ArrayList<Student> students){
                
                for(Student student: students){
                    student.saveDisplay();
                }
            }
            public void saveDisplay(){
                System.out.println("-------------------------------------------" + "\nDetails: \nSTUDENT ID: " + id + "\nSTUDENT NAME: " + name +"\nSTUDENT AGE: " + age + "\nSTUDENT EMAIL: " + email + "\nSTUDENT COURSE: " + course + "\n-------------------------------------------");
            }
            
            
                
}
